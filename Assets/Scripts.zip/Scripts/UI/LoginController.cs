using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using SolarEdu; // ← tambahan untuk plugin SolarEdu

/// <summary>
/// Mengelola panel Login dan Sign-Up di scene Login.
/// Referensi UI di-assign via Inspector (SerializeField).
/// Autentikasi ditangani oleh <see cref="SolarEduAuth"/> (ke server dashboard).
/// </summary>
public class LoginController : MonoBehaviour
{
    [Header("Scene Target")]
    [Tooltip("Nama scene yang dimuat setelah berhasil login.")]
    [SerializeField] private string nextSceneName = "Menu";

    [Header("Panels")]
    [SerializeField] private GameObject loginPanel;
    [SerializeField] private GameObject signupPanel;

    [Header("Login Fields")]
    [SerializeField] private TMP_InputField loginUsername;
    [SerializeField] private TMP_InputField loginPassword;
    [SerializeField] private TMP_Text       loginError;

    [Header("Signup Fields")]
    [SerializeField] private TMP_InputField signupName;
    [SerializeField] private TMP_InputField signupEmail;
    [SerializeField] private TMP_InputField signupPassword;
    [SerializeField] private TMP_InputField signupConfirm;
    [SerializeField] private TMP_InputField signupClassCode;
    [SerializeField] private TMP_Text       signupError;

    // Referensi ke SolarEduAuth (dicari otomatis)
    private SolarEduAuth auth;

    // ── Lifecycle ──────────────────────────────────────────────────────────

    private void Start()
    {
        // Cari SolarEduAuth di scene
        auth = FindFirstObjectByType<SolarEduAuth>();
        if (auth == null)
        {
            Debug.LogError("[LoginController] SolarEduAuth tidak ditemukan di scene! Pastikan GameObject [SolarEdu] sudah ada.");
        }

        // Fallback auto-wire jika Inspector belum di-assign
        if (loginPanel == null || signupPanel == null)
            AutoWire();

        // Cek auto-login (sudah pernah login sebelumnya?)
        if (auth != null && auth.TryAutoLogin())
        {
            Debug.Log("[LoginController] Auto-login berhasil, langsung masuk...");
            SceneManager.LoadScene(nextSceneName);
            return;
        }

        ShowLogin();
    }

    // ── Auto-wire fallback ─────────────────────────────────────────────────

    /// <summary>Fallback: temukan referensi UI secara rekursif bila belum di-assign dari Inspector.</summary>
    private void AutoWire()
    {
        var canvas = FindFirstObjectByType<Canvas>();
        if (canvas == null) { Debug.LogError("[LoginController] Canvas tidak ditemukan."); return; }

        if (loginPanel  == null) loginPanel  = FindChildRecursive(canvas.gameObject, "LoginPanel");
        if (signupPanel == null) signupPanel = FindChildRecursive(canvas.gameObject, "SignupPanel");

        if (loginPanel != null)
        {
            if (loginUsername == null) loginUsername = FindInputRecursive(loginPanel, "UsernameField");
            if (loginPassword == null) loginPassword = FindInputRecursive(loginPanel, "PasswordField");
            if (loginError    == null) loginError    = FindTextRecursive(loginPanel,  "ErrorText");
        }
        else
        {
            Debug.LogError("[LoginController] LoginPanel tidak ditemukan.");
        }

        if (signupPanel != null)
        {
            if (signupName      == null) signupName      = FindInputRecursive(signupPanel, "NameField");
            if (signupEmail     == null) signupEmail     = FindInputRecursive(signupPanel, "EmailField");
            if (signupPassword  == null) signupPassword  = FindInputRecursive(signupPanel, "PasswordField");
            if (signupConfirm   == null) signupConfirm   = FindInputRecursive(signupPanel, "ConfirmField");
            if (signupClassCode == null) signupClassCode = FindInputRecursive(signupPanel, "ClassCodeField");
            if (signupError     == null) signupError     = FindTextRecursive(signupPanel,  "ErrorText");
        }
        else
        {
            Debug.LogError("[LoginController] SignupPanel tidak ditemukan.");
        }
    }

    // ── Panel switching ────────────────────────────────────────────────────

    /// <summary>Tampilkan panel Login dan sembunyikan Sign-Up.</summary>
    public void ShowLogin()
    {
        SetActive(loginPanel,  true);
        SetActive(signupPanel, false);
        ClearInputs();
        ClearErrors();
    }

    /// <summary>Tampilkan panel Sign-Up dan sembunyikan Login.</summary>
    public void ShowSignup()
    {
        SetActive(loginPanel,  false);
        SetActive(signupPanel, true);
        ClearInputs();
        ClearErrors();
    }

    // ── Login ──────────────────────────────────────────────────────────────

    /// <summary>Validasi input lalu proses login lewat SolarEduAuth (ke server).</summary>
    public void OnLoginClicked()
    {
        string user = loginUsername != null ? loginUsername.text.Trim() : "";
        string pass = loginPassword != null ? loginPassword.text        : "";

        if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
        {
            ShowError(loginError, "Email dan password tidak boleh kosong.");
            return;
        }

        if (auth == null)
        {
            ShowError(loginError, "Sistem tidak siap. Restart game.");
            return;
        }

        if (auth.IsLoading)
        {
            return; // Sedang proses, jangan kirim lagi
        }

        // Tampilkan loading
        ShowError(loginError, "Masuk...");

        // Kirim ke server dashboard
        auth.Login(
            user,  // email
            pass,
            onSuccess: (userData) =>
            {
                // Login berhasil! Pindah ke scene game
                Debug.Log($"[LoginController] Login OK: {userData.name} ({userData.className})");
                SceneManager.LoadScene(nextSceneName);
            },
            onError: (msg) =>
            {
                // Tampilkan error dari server
                ShowError(loginError, msg);
            }
        );
    }

    // ── Sign-Up ────────────────────────────────────────────────────────────

    /// <summary>Validasi input lalu daftarkan akun baru lewat SolarEduAuth (ke server).</summary>
    public void OnSignupClicked()
    {
        string name      = signupName      != null ? signupName.text.Trim()      : "";
        string email     = signupEmail     != null ? signupEmail.text.Trim()     : "";
        string pass      = signupPassword  != null ? signupPassword.text         : "";
        string confirm   = signupConfirm   != null ? signupConfirm.text          : "";
        string classCode = signupClassCode != null ? signupClassCode.text.Trim() : "";

        // ── Validasi lokal ──

        if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) ||
            string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(classCode))
        {
            ShowError(signupError, "Semua field harus diisi.");
            return;
        }

        if (!email.Contains("@"))
        {
            ShowError(signupError, "Format email tidak valid.");
            return;
        }

        if (pass.Length < 6)
        {
            ShowError(signupError, "Password minimal 6 karakter.");
            return;
        }

        if (pass != confirm)
        {
            ShowError(signupError, "Konfirmasi password tidak cocok.");
            return;
        }

        if (auth == null)
        {
            ShowError(signupError, "Sistem tidak siap. Restart game.");
            return;
        }

        if (auth.IsLoading)
        {
            return; // Sedang proses, jangan kirim lagi
        }

        // Tampilkan loading
        ShowError(signupError, "Mendaftar...");

        // Kirim ke server dashboard
        // Kode kelas divalidasi oleh server (tidak perlu ClassCodeConfig lagi)
        auth.Register(
            name,
            email,
            pass,
            classCode,
            onSuccess: (userData) =>
            {
                // Register berhasil! Langsung masuk ke game
                Debug.Log($"[LoginController] Register OK: {userData.name} → {userData.className}");
                SceneManager.LoadScene(nextSceneName);
            },
            onError: (msg) =>
            {
                // Tampilkan error dari server, misal:
                // "Kode undangan tidak valid"
                // "Email sudah terdaftar"
                ShowError(signupError, msg);
            }
        );
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private static GameObject FindChildRecursive(GameObject root, string targetName)
    {
        foreach (Transform t in root.GetComponentsInChildren<Transform>(true))
            if (t.name == targetName) return t.gameObject;
        Debug.LogWarning($"[LoginController] '{targetName}' tidak ditemukan di bawah '{root.name}'.");
        return null;
    }

    private static TMP_InputField FindInputRecursive(GameObject panel, string fieldName)
    {
        foreach (Transform t in panel.GetComponentsInChildren<Transform>(true))
            if (t.name == fieldName)
            {
                var input = t.GetComponentInChildren<TMP_InputField>(true);
                if (input != null) return input;
            }
        Debug.LogWarning($"[LoginController] InputField '{fieldName}' tidak ditemukan di '{panel.name}'.");
        return null;
    }

    private static TMP_Text FindTextRecursive(GameObject panel, string textName)
    {
        foreach (Transform t in panel.GetComponentsInChildren<Transform>(true))
            if (t.name == textName)
            {
                var text = t.GetComponent<TMP_Text>();
                if (text != null) return text;
            }
        Debug.LogWarning($"[LoginController] TMP_Text '{textName}' tidak ditemukan di '{panel.name}'.");
        return null;
    }

    private static void SetActive(GameObject go, bool active)
    {
        if (go != null) go.SetActive(active);
    }

    private static void ShowError(TMP_Text label, string msg)
    {
        if (label == null) return;
        label.text = msg;
        label.gameObject.SetActive(true);
    }

    private void ClearErrors()
    {
        if (loginError  != null) { loginError.text  = ""; loginError.gameObject.SetActive(false); }
        if (signupError != null) { signupError.text = ""; signupError.gameObject.SetActive(false); }
    }

    private void ClearInputs()
    {
        if (loginUsername  != null) loginUsername.text  = "";
        if (loginPassword  != null) loginPassword.text  = "";
        if (signupName     != null) signupName.text     = "";
        if (signupEmail    != null) signupEmail.text    = "";
        if (signupPassword != null) signupPassword.text = "";
        if (signupConfirm  != null) signupConfirm.text  = "";
        if (signupClassCode != null) signupClassCode.text = "";
    }
}
