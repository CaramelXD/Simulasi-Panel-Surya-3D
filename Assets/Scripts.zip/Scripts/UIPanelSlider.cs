using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Slides a UI panel in/out from either the left or right edge of the screen.
/// Attach this to the panel's GameObject, then assign the toggle button.
/// </summary>
public class UIPanelSlider : MonoBehaviour
{
    public enum SlideDirection { Left, Right }

    [Header("References")]
    [Tooltip("Button that triggers show/hide.")]
    [SerializeField] private Button toggleButton;

    [Tooltip("Optional: Text component on the button to update its label.")]
    [SerializeField] private Text buttonLabel;

    [Tooltip("GameObjects to deactivate while this panel is visible (e.g. room button container).")]
    [SerializeField] private GameObject[] objectsToHideWhenVisible;

    [Header("Settings")]
    [Tooltip("Which side this panel originates from.")]
    [SerializeField] private SlideDirection panelSide = SlideDirection.Left;

    [Tooltip("Distance in pixels the panel travels when hiding. Set to 0 to auto-use the panel's width.")]
    [SerializeField] private float slideDistance = 0f;

    [Tooltip("Duration of the slide animation in seconds.")]
    [SerializeField] private float slideDuration = 0.3f;

    [Tooltip("Text shown on the button when the panel is hidden.")]
    [SerializeField] private string showText = "Show UI";

    [Tooltip("Text shown on the button when the panel is visible.")]
    [SerializeField] private string hideText = "Hide UI";

    private RectTransform _rectTransform;
    private bool _isVisible = true;
    private bool _isAnimating = false;
    private bool _positionsCached = false;
    private Vector2 _visiblePosition;
    private Vector2 _hiddenPosition;

    private void Awake()
    {
        _rectTransform = GetComponent<RectTransform>();

        // Jangan timpa posisi jika sudah di-cache oleh SlideIn() sebelum Awake
        if (!_positionsCached)
            CachePositions();

        if (toggleButton != null)
            toggleButton.onClick.AddListener(Toggle);

        UpdateButtonLabel();
    }

    private void OnEnable()
    {
        // Saat panel diaktifkan (termasuk via SetActive), hide dependent objects
        _isVisible = true;
        UpdateDependentObjects();
    }

    private void OnDisable()
    {
        // Saat panel dinonaktifkan, show dependent objects kembali
        _isVisible = false;
        UpdateDependentObjects();
    }


    /// <summary>
    /// Computes visible and hidden anchored positions based on slide distance and panel side.
    /// If slideDistance is 0, the panel's width is used automatically.
    /// </summary>
    private void CachePositions()
    {
        _visiblePosition = _rectTransform.anchoredPosition;

        float distance = slideDistance > 0f ? slideDistance : _rectTransform.rect.width;

        // Left panel slides left (negative X) to hide, right panel slides right (positive X).
        float hiddenOffset = panelSide == SlideDirection.Left ? -distance : distance;
        _hiddenPosition = new Vector2(_visiblePosition.x + hiddenOffset, _visiblePosition.y);
        _positionsCached = true;
    }

    /// <summary>
    /// Toggles the panel between visible and hidden state.
    /// </summary>
    public void Toggle()
    {
        if (_isAnimating) return;

        _isVisible = !_isVisible;
        UpdateButtonLabel();
        UpdateDependentObjects();
        StartCoroutine(SlideCoroutine(_isVisible ? _visiblePosition : _hiddenPosition));
    }

    /// <summary>
    /// Forces the panel to a specific state instantly, without animation.
    /// </summary>
    public void SetVisible(bool visible)
    {
        StopAllCoroutines();
        _isAnimating = false;
        _isVisible = visible;
        _rectTransform.anchoredPosition = _isVisible ? _visiblePosition : _hiddenPosition;
        UpdateButtonLabel();
        UpdateDependentObjects();
    }

    /// <summary>
    /// Resets the panel to the visible position instantly without affecting dependent objects.
    /// Use this when an external system activates/deactivates the panel and should not interfere
    /// with the slide-driven visibility of dependent objects.
    /// </summary>
    public void ResetToVisible()
    {
        StopAllCoroutines();
        _isAnimating = false;
        _isVisible = true;
        _rectTransform.anchoredPosition = _visiblePosition;
        UpdateButtonLabel();
    }

    /// <summary>
    /// Aktifkan panel dari posisi hidden, lalu animasikan slide masuk ke posisi visible.
    /// Cocok dipanggil oleh sistem luar (misal SolarPanelInstaller) saat panel perlu muncul.
    /// </summary>
    public void SlideIn()
    {
        if (_rectTransform == null)
            _rectTransform = GetComponent<RectTransform>();

        // Cache posisi visible dari anchoredPosition saat ini (sebelum dipindah)
        if (!_positionsCached)
            CachePositions();

        // Pindah ke posisi hidden dulu, lalu aktifkan GO
        _rectTransform.anchoredPosition = _hiddenPosition;
        gameObject.SetActive(true);

        _isVisible = true;
        UpdateButtonLabel();
        UpdateDependentObjects();
        StopAllCoroutines();
        StartCoroutine(SlideCoroutine(_visiblePosition));
    }

    /// <summary>
    /// Animasikan slide keluar lalu nonaktifkan GameObject.
    /// </summary>
    public void SlideOut(System.Action onComplete = null)
    {
        if (_rectTransform == null)
            _rectTransform = GetComponent<RectTransform>();

        CachePositions();

        _isVisible = false;
        UpdateButtonLabel();
        UpdateDependentObjects();
        StartCoroutine(SlideOutCoroutine(onComplete));
    }

    private IEnumerator SlideOutCoroutine(System.Action onComplete)
    {
        yield return SlideCoroutine(_hiddenPosition);
        gameObject.SetActive(false);
        onComplete?.Invoke();
    }

    private IEnumerator SlideCoroutine(Vector2 targetPosition)
    {
        _isAnimating = true;
        Vector2 startPosition = _rectTransform.anchoredPosition;
        float elapsed = 0f;

        while (elapsed < slideDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(elapsed / slideDuration);

            // Smooth-step easing — same formula used in OrbitCamera.
            float eased = t * t * (3f - 2f * t);
            _rectTransform.anchoredPosition = Vector2.LerpUnclamped(startPosition, targetPosition, eased);

            yield return null;
        }

        _rectTransform.anchoredPosition = targetPosition;
        _isAnimating = false;
    }

    private void UpdateButtonLabel()
    {
        if (buttonLabel == null) return;
        buttonLabel.text = _isVisible ? hideText : showText;
    }

    /// <summary>
    /// Activates or deactivates all objects in objectsToHideWhenVisible
    /// based on the current panel visibility: hidden when panel is visible, shown when panel is hidden.
    /// </summary>
    private void UpdateDependentObjects()
    {
        if (objectsToHideWhenVisible == null) return;

        foreach (GameObject obj in objectsToHideWhenVisible)
        {
            if (obj != null)
                obj.SetActive(!_isVisible);
        }
    }
}
