using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

/// <summary>
/// Satu kartu furnitur di panel catalog.
/// Attach ke prefab Card UI, pasang referensi data via FurnitureCatalogUI.
/// </summary>
public class FurnitureCardUI : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("UI References")]
    public Image iconImage;
    public TextMeshProUGUI nameText;
    public TextMeshProUGUI wattText;
    public Button actionButton;
    public TextMeshProUGUI actionButtonText;
    public Button configButton;                // Tombol untuk membuka konfigurasi jam aktif
    public GameObject hoverOverlay;            // Panel gelap di atas card saat hover

    // Data furnitur yang diwakili kartu ini
    private FurnitureData data;

    // ── Setup ──────────────────────────────────────────────────────────────
    public void Initialize(FurnitureData furnitureData)
    {
        data = furnitureData;

        // Isi konten
        if (iconImage != null && data.icon != null)
            iconImage.sprite = data.icon;

        if (nameText != null)
            nameText.text = data.furnitureName;

        if (wattText != null)
            wattText.text = $"{data.wattConsumption} W";

        // Sembunyikan hover overlay
        if (hoverOverlay != null)
            hoverOverlay.SetActive(false);

        // Sambungkan tombol
        if (actionButton != null)
            actionButton.onClick.AddListener(OnActionClicked);

        if (configButton != null)
            configButton.onClick.AddListener(OnConfigClicked);

        // Update tampilan awal
        RefreshButtonState();

        // Dengarkan perubahan state dari FurnitureManager
        if (FurnitureManager.Instance != null)
            FurnitureManager.Instance.OnPowerChanged.AddListener(_ => RefreshButtonState());
    }

    // ── Button Logic ───────────────────────────────────────────────────────

    void OnActionClicked()
    {
        if (FurnitureManager.Instance == null) return;

        if (FurnitureManager.Instance.IsPlaced(data))
        {
            FurnitureManager.Instance.RemoveFurniture(data);
        }
        else
        {
            FurnitureManager.Instance.AddFurniture(data);
        }

        RefreshButtonState();
    }

    void OnConfigClicked()
    {
        if (data == null) return;

        if (FurnitureManager.Instance != null && !FurnitureManager.Instance.IsPlaced(data))
        {
            Debug.Log($"[FurnitureCardUI] {data.furnitureName} belum ditempatkan di rumah. Tambahkan dulu sebelum mengkonfigurasi jam aktif.");
            return;
        }

        var panel = FurnitureConfigPanel.Instance
                    ?? FindFirstObjectByType<FurnitureConfigPanel>(FindObjectsInactive.Include);

        if (panel != null)
            panel.Open(data);
        else
            Debug.LogWarning("[FurnitureCardUI] FurnitureConfigPanel tidak ditemukan di scene.");
    }

    /// Update teks & warna tombol sesuai state (sudah dipasang atau belum)
    void RefreshButtonState()
    {
        if (FurnitureManager.Instance == null || actionButtonText == null) return;

        bool alreadyPlaced = FurnitureManager.Instance.IsPlaced(data);

        if (alreadyPlaced)
        {
            actionButtonText.text = "✕ Hapus";
            // Merah untuk hapus
            actionButton.GetComponent<Image>().color = new Color(0.85f, 0.2f, 0.2f);
        }
        else
        {
            actionButtonText.text = "＋ Masukan ke Rumah";
            // Hijau untuk tambah
            actionButton.GetComponent<Image>().color = new Color(0.15f, 0.7f, 0.35f);
        }

        // Config button selalu tampil dan selalu interactable
        if (configButton != null)
            configButton.gameObject.SetActive(true);
    }

    // ── Hover Effects ──────────────────────────────────────────────────────
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (hoverOverlay != null)
            hoverOverlay.SetActive(true);

        // Scale up sedikit (pulse effect)
        transform.localScale = Vector3.one * 1.03f;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (hoverOverlay != null)
            hoverOverlay.SetActive(false);

        transform.localScale = Vector3.one;
    }
}
