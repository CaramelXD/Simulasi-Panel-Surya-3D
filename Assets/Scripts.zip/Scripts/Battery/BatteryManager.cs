using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// Singleton yang mengatur aliran energi:
///
///   Solar Panels → [EnergyPool] → Battery (dicapped oleh MaxChargeRate)
///
/// EnergyPool naik setiap frame dari output semua panel terdaftar.
/// Battery mengambil dari pool dengan kecepatan maksimum MaxChargeRate (kWh/s).
/// Jika pool kosong, battery tidak bisa mengisi walau ada panel.
/// Furnitur menguras battery langsung (bukan dari pool).
/// </summary>
public class BatteryManager : MonoBehaviour
{
    public static BatteryManager Instance { get; private set; }

    // ── Events ─────────────────────────────────────────────────────────────
    /// <summary>Dipanggil setiap charge battery berubah. Parameter: currentCharge (kWh).</summary>
    public UnityEvent<float> OnChargeChanged;

    /// <summary>Dipanggil saat state daya berubah (ada daya / tidak ada daya).</summary>
    public UnityEvent<bool> OnPowerStateChanged;

    /// <summary>Dipanggil saat jumlah panel yang terdaftar berubah.</summary>
    public UnityEvent OnPanelCountChanged;

    /// <summary>Dipanggil setiap total energi yang terpakai furnitur berubah. Parameter: total kWh.</summary>
    public UnityEvent<float> OnEnergyConsumedChanged;

    // ── Inspector ──────────────────────────────────────────────────────────
    [Header("Battery Specs")]
    [Tooltip("Kapasitas maksimum battery dalam kWh.")]
    [SerializeField] private float maxCapacity = 10f;

    [Tooltip("Kecepatan maksimum pengisian battery dari pool (kWh per detik).")]
    [SerializeField] private float maxChargeRate = 0.5f;

    [Tooltip("Ambang batas minimum charge (kWh) sebelum dianggap kosong.")]
    [SerializeField] private float emptyThreshold = 0.001f;

    [Tooltip("Efisiensi inverter untuk konversi DC ke AC (0-1). Default 0.90 = 90%.")]
    [SerializeField] private float inverterEfficiency = 0.90f;

    // ── State ──────────────────────────────────────────────────────────────
    public float CurrentCharge { get; private set; } = 0f;
    public float MaxCapacity   => maxCapacity;
    public float MaxChargeRate => maxChargeRate;

    /// <summary>
    /// Pool energi yang diisi panel surya dan dikuras oleh battery.
    /// Ini yang ditampilkan sebagai "Total Energy" di UI.
    /// </summary>
    public float EnergyPool { get; private set; } = 0f;

    /// <summary>Total energi kumulatif yang dikonsumsi furnitur sejak simulasi dimulai (kWh).</summary>
    public float TotalEnergyConsumed { get; private set; } = 0f;

    /// <summary>Total energi kumulatif yang dihasilkan semua panel surya selama simulasi (kWh).</summary>
    public float TotalSolarEnergyGenerated { get; private set; } = 0f;

    /// <summary>True jika selama simulasi daya tidak pernah habis saat furnitur aktif.</summary>
    public bool WasPowerAlwaysSufficient => !_powerEverInsufficient;
    private bool _powerEverInsufficient = false;

    /// <summary>
    /// Akumulasi jam simulasi yang sudah berlalu sejak simulasi dimulai.
    /// Digunakan sebagai grace period untuk menghindari false-positive di frame pertama
    /// saat baterai masih 0 dan solar belum sempat mengisi.
    /// </summary>
    private float _simElapsedHours = 0f;

    /// <summary>
    /// Grace period (jam simulasi) sebelum pengecekan kecukupan daya dimulai.
    /// Cukup singkat (0.05 sim-jam ≈ 3 menit jam simulasi) untuk menghindari false-positive
    /// awal, tapi cukup cepat agar deteksi tidak tertunda secara signifikan.
    /// </summary>
    private const float SufficiencyGracePeriodHours = 0.05f;

    /// <summary>Persentase charge saat ini (0-1).</summary>
    public float ChargeRatio => maxCapacity > 0f ? CurrentCharge / maxCapacity : 0f;

    /// <summary>True jika battery masih punya daya di atas threshold.</summary>
    public bool HasPower => CurrentCharge > emptyThreshold;

    /// <summary>Jumlah solar panel yang saat ini terdaftar.</summary>
    public int PanelCount => _registeredPanels.Count;

    /// <summary>Total output daya semua panel surya yang terdaftar saat ini (Watt).</summary>
    public float CurrentSolarPower { get; private set; } = 0f;

    /// <summary>Output AC saat ini (Watt) = daya DC x efisiensi inverter.</summary>
    public float CurrentACOutput { get; private set; } = 0f;

    /// <summary>Efisiensi inverter DC-AC (0-1).</summary>
    public float InverterEfficiency => inverterEfficiency;

    private bool _lastHasPower = false;
    private readonly List<SolarPanel> _registeredPanels = new();
    private SunController _sunController;

    // ── Lifecycle ──────────────────────────────────────────────────────────
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        CurrentCharge             = 0f;
        EnergyPool                = 0f;
        TotalEnergyConsumed       = 0f;
        TotalSolarEnergyGenerated = 0f;
        _powerEverInsufficient    = false;
        _simElapsedHours          = 0f;
        _lastHasPower             = false;
    }

    private void Start()
    {
        _sunController = FindFirstObjectByType<SunController>();

        // Auto-discover panel yang sudah ada di scene
        foreach (SolarPanel panel in FindObjectsByType<SolarPanel>(FindObjectsSortMode.None))
            RegisterPanel(panel);
    }

    private void Update()
    {
        // Selalu perbarui CurrentSolarPower agar kabel bisa bereaksi meski simulasi belum jalan
        float solarInput = 0f;
        foreach (SolarPanel panel in _registeredPanels)
            if (panel != null) solarInput += panel.CurrentPower;
        CurrentSolarPower = solarInput;

        // Output AC = daya DC x efisiensi inverter
        CurrentACOutput = solarInput * inverterEfficiency;

        if (SimulationManager.Instance == null || !SimulationManager.Instance.IsSimulationRunning)
            return;

        // Hitung delta jam simulasi per frame
        // Dengan dayDuration=24: 1 detik real = 1 jam simulasi
        float simHoursPerSec = _sunController != null ? _sunController.SimulationHoursPerSecond : 1f;
        float deltaSimHours = simHoursPerSec * Time.deltaTime;

        // Akumulasi waktu simulasi (untuk grace period kecukupan daya)
        _simElapsedHours += deltaSimHours;

        // 1. Isi pool dari output semua panel (Watt × jam / 1000 → kWh)
        EnergyPool += solarInput * deltaSimHours / 1000f;
        TotalSolarEnergyGenerated += solarInput * deltaSimHours / 1000f;

        // 2. Battery mengambil dari pool, dibatasi maxChargeRate.
        float chargeFromPool = 0f;
        if (CurrentCharge < maxCapacity)
        {
            float maxTakeThisFrame = maxChargeRate * deltaSimHours;
            chargeFromPool = Mathf.Min(maxTakeThisFrame, EnergyPool);
            EnergyPool = Mathf.Max(0f, EnergyPool - chargeFromPool);
        }

        // 3. Drain furnitur langsung dari battery (Watt × jam / 1000 → kWh)
        float drainKwh = 0f;
        if (HasPower && FurnitureManager.Instance != null)
        {
            float currentSimHour = _sunController != null ? _sunController.TimeOfDay : 0f;
            float activeWatt     = FurnitureManager.Instance.GetActiveWattConsumed(currentSimHour);
            drainKwh             = activeWatt * deltaSimHours / 1000f;
        }

        // Akumulasi total konsumsi energi furnitur
        if (drainKwh > 0f)
        {
            TotalEnergyConsumed += drainKwh;
            OnEnergyConsumedChanged?.Invoke(TotalEnergyConsumed);
        }

        // 4. Update charge battery
        float netDelta   = chargeFromPool - drainKwh;
        float prevCharge = CurrentCharge;
        CurrentCharge    = Mathf.Clamp(CurrentCharge + netDelta, 0f, maxCapacity);

        // Catat jika daya tidak cukup saat ada furnitur aktif —
        // hanya setelah grace period singkat berlalu agar false-positive frame pertama dihindari.
        if (_simElapsedHours >= SufficiencyGracePeriodHours
            && !HasPower
            && FurnitureManager.Instance != null
            && FurnitureManager.Instance.GetActiveWattConsumed(_sunController != null ? _sunController.TimeOfDay : 0f) > 0f)
        {
            _powerEverInsufficient = true;
        }

        if (!Mathf.Approximately(CurrentCharge, prevCharge))
            OnChargeChanged?.Invoke(CurrentCharge);

        bool currentHasPower = HasPower;
        if (currentHasPower != _lastHasPower)
        {
            _lastHasPower = currentHasPower;
            OnPowerStateChanged?.Invoke(currentHasPower);
        }
    }

    // ── Consumption Reset ──────────────────────────────────────────────────

    /// <summary>
    /// Reset semua state energi ke kondisi awal.
    /// Panggil ini saat simulasi baru dimulai.
    /// </summary>
    public void ResetConsumption()
    {
        CurrentCharge             = 0f;
        EnergyPool                = 0f;
        TotalEnergyConsumed       = 0f;
        TotalSolarEnergyGenerated = 0f;
        _powerEverInsufficient    = false;
        _simElapsedHours          = 0f;

        // Reset energi kumulatif semua panel agar label kWh mulai dari 0 di tiap simulasi
        foreach (SolarPanel panel in _registeredPanels)
            if (panel != null) panel.ResetTotalEnergy();

        OnEnergyConsumedChanged?.Invoke(TotalEnergyConsumed);
        OnChargeChanged?.Invoke(CurrentCharge);
    }

    // ── Battery Count ──────────────────────────────────────────────────────

    private int _installedBatteryCount = 0;

    /// <summary>Jumlah unit baterai yang saat ini terpasang.</summary>
    public int InstalledBatteryCount => _installedBatteryCount;

    /// <summary>Dipanggil saat jumlah unit baterai terpasang berubah.</summary>
    public UnityEvent<int> OnBatteryCountChanged;

    /// <summary>Tambah satu unit baterai. Dipanggil oleh BatteryInstaller saat instalasi.</summary>
    public void NotifyBatteryInstalled()
    {
        _installedBatteryCount++;
        OnBatteryCountChanged?.Invoke(_installedBatteryCount);
        Debug.Log($"[BatteryManager] Baterai terpasang: {_installedBatteryCount}");
    }

    /// <summary>Kurangi satu unit baterai. Dipanggil oleh BatteryInstaller saat copot.</summary>
    public void NotifyBatteryRemoved()
    {
        _installedBatteryCount = Mathf.Max(0, _installedBatteryCount - 1);
        OnBatteryCountChanged?.Invoke(_installedBatteryCount);
        Debug.Log($"[BatteryManager] Baterai dicopot: {_installedBatteryCount}");
    }

    // ── Panel Registration ─────────────────────────────────────────────────

    /// <summary>
    /// Daftarkan solar panel ke battery.
    /// TotalEnergy yang sudah terkumpul di panel langsung dimasukkan ke EnergyPool.
    /// </summary>
    public void RegisterPanel(SolarPanel panel)
    {
        if (panel == null || _registeredPanels.Contains(panel)) return;

        _registeredPanels.Add(panel);

        // Masukkan energi yang sudah dihasilkan panel sebelumnya ke pool
        if (panel.TotalEnergy > 0f)
            EnergyPool += panel.TotalEnergy;

        OnPanelCountChanged?.Invoke();
    }

    /// <summary>Hapus solar panel dari daftar (misal saat panel dicopot).</summary>
    public void UnregisterPanel(SolarPanel panel)
    {
        _registeredPanels.Remove(panel);
        OnPanelCountChanged?.Invoke();
    }
}
